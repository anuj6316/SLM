# Baselines

This repository contains code and documentation for all baselines shown on [the paper]() and [the leaderboard](https://yale-lily.github.io/spider).
